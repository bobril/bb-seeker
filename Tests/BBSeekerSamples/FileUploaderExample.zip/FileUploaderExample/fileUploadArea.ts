import * as b from "bobril";
import { IUploadAreaOptions, UploadArea } from "pure-upload";
import { Area } from "helpers--fileupload";
import { uploader } from "./uploader";

export interface IData {
    children?: b.IBobrilChildren;
    options: IUploadAreaOptions;
    onAreaRegistered?: (area: UploadArea) => void;
    element?: HTMLElement;
}

export let create = (data: IData): b.IBobrilNode => {
    const enhancedOptions: IUploadAreaOptions = data.options;
    enhancedOptions.headers = Object.assign({}, data.options.headers);

    return Area.create({
        children: data.children,
        options: enhancedOptions,
        element: data.element,
        onAreaRegistered: data.onAreaRegistered,
        localizer: {
            fileSizeInvalid: maxFileSize =>
                "The selected file exceeds the allowed size of { maxFileSize } MB or its size is 0 MB.",
            fileTypeInvalid: accept => "File format is not allowed. Only { accept } files are allowed.",
            invalidResponseFromServer: () =>"Invalid response from server"
        },
        uploader
    });
};

export default create;
