import { t } from "bobril-g11n";
import { Queue } from "helpers--fileupload";
import { uploader } from "./uploader";
import { IBobrilNode } from "bobril";

export const create: () => IBobrilNode = () => {
    return Queue.create({
        addError: () => {},
        notifications: {
            register(name: string, callback) {
                return () => "";
            },
            unregister(name: string, callback) {
                return () => "";
            }
        },
        processingNotifications: [],
        uploader,
        onFileStatusClick: file => {
            
        }
    });
};

export const fileUploadQueue: () => IBobrilNode = create;
