import * as b from "bobril";
import * as FileSelection from "bobwai--file-selection";
import * as LField from "bobwai--l-field";
import * as LFieldGroup from "bobwai--l-field-group";

import * as UploadArea from "./fileUploadArea";

b.init(() => {
  return LFieldGroup.create({
    content: [
      LField.create({
        labelContent: "First file input",
        valueContent: FileSelection.create({
          value: "first",
          coverContent: UploadArea.create({ options: { url: "a", method: "" } })
        })
      }),
      LField.create({
        labelContent: "Second file input",
        valueContent: FileSelection.create({
          value: "second",
          coverContent: UploadArea.create({ options: { url: "a", method: "" } })
        })
      })
    ]
  });
});
