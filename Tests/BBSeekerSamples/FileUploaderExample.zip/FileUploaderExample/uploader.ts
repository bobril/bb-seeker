import * as b from "bobril";
import * as FileSelection from "bobwai--file-selection";
import * as fileUploadArea from "./fileUploadArea";
import { Uploader } from "helpers--fileupload";
import { t } from "bobril-g11n";
import { IUploadFile, Uploader as pUploader } from "pure-upload";
import * as FormElements from "bobwai--form-elements";
import * as ToolTip from "bobwai--tooltip-emplacer";

export { IUploadFileExt } from "helpers--fileupload";

export const uploader: pUploader = Uploader.registerUploader(() => {
    return;
});
export const getUrlBuilder: (continent: string, fileType: string, ...target: string[]) => (file: IUploadFile) => string =
    Uploader.getUrlBuilder;

export interface ICreateFileUploaderParams {
    accept: string;
    fileName: string;
    maxFileSizeInMegabyte: number;
    uploader: string;
    uploaderArgs: string[];
    onDelete: () => void;
    validationState?: FormElements.ValidationState;
    tooltipMessage?: string;
}

export function createFileUploader(params: ICreateFileUploaderParams): b.IBobrilNode {
    if (params.fileName) {
        return ToolTip.create({
            content: FileSelection.create({
                onDelete: params.onDelete,
                value: params.fileName,
                validationState: params.validationState
            }),
            tooltipMessage: params.tooltipMessage,
            validationState: params.validationState
        });
    }
    return fileUploadArea.create({
        options: {
            accept: params.accept,
            clickable: true,
            url: getUrlBuilder("MobileBackend", params.uploader, params.uploaderArgs.join("/")),
            method: "POST",
            multiple: false,
            maxFileSize: params.maxFileSizeInMegabyte
        },
        children: FileSelection.create({
            placeholder: t("No file selected"),
            value: undefined
        })
    });
}
