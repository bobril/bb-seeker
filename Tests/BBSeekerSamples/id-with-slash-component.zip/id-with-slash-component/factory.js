/// <reference path="../../Libraries/bobril/library.d.ts"/>
/// <reference path="../../Libraries/dc-helpers/library.ts"/>
"use strict";
function idWithSlashComponentFactory() {
    return {
        tag: "div",
        component: {
            id: "/IdWithSlashComponent"
        }
    };
}
exports.idWithSlashComponentFactory = idWithSlashComponentFactory;
