/// <reference path="../../Libraries/bobril/library.d.ts"/>
/// <reference path="../../Libraries/dc-helpers/library.ts"/>

export function idWithSlashComponentFactory(): IBobrilNode {
    return {
        tag: "div",
        component: {
            id: "/IdWithSlashComponent"
        }
    };
}